import React, { useState, useEffect } from 'react';
import {
  Mic,
  MicOff,
  VideoOff,
  Send,
  Copy,
  Check,
  Code2,
  Terminal,
  CheckCircle,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Project,
  InterviewMode,
  InterviewResult,
  SubmittedAnswer,
  StudentPage,
} from '../../types';

interface PracticeInterviewProps {
  projects: Project[];
  selectedProject: Project;
  onSelectProject: (p: Project) => void;
  onCompleteInterview: (result: InterviewResult) => void;
  onNavigate: (page: StudentPage) => void;
  initialMode?: InterviewMode;
}

export const PracticeInterview: React.FC<PracticeInterviewProps> = ({
  selectedProject,
  onCompleteInterview,
  onNavigate,
}) => {
  const [response, setResponse] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionStep, setSubmissionStep] = useState('Analyzing code rationale...');
  const [activeLang, setActiveLang] = useState<'java' | 'cpp'>('java');

  // Sample answer matching the TCS Ninja question
  const sampleAnswer =
    'Method overloading represents compile-time polymorphism where methods within the same class share a name but differ in parameter count or parameter types. The compiler determines which method to bind based on method signatures.\n\nIn contrast, method overriding is runtime polymorphism through inheritance where a subclass provides a specific implementation of a method declared in its superclass using the @Override annotation.\n\nUnder the hood, runtime polymorphism works via dynamic method dispatch using virtual method tables (vtables). In Java and C++, each class with virtual methods holds a vtable containing pointers to the class implementations. Every object instance contains an internal pointer (vptr) to its class vtable. When obj.display() is invoked at runtime on a Base reference holding a Derived instance, the JVM inspects the object\'s actual runtime type, looks up Derived\'s vtable, and jumps to Derived.display(). This dynamic lookup ensures correct polymorphic behavior with O(1) table indirection overhead.';

  const javaSnippet = `// Java Dynamic Dispatch Demonstration
class Base {
    void display() { System.out.println("Base"); }
}
class Derived extends Base {
    @Override
    void display() { System.out.println("Derived"); }
}
Base obj = new Derived();
obj.display(); // Calls Derived.display() at runtime`;

  const cppSnippet = `// C++ Dynamic Dispatch via vtable
class Base {
public:
    virtual void display() { std::cout << "Base\\n"; }
};
class Derived : public Base {
public:
    void display() override { std::cout << "Derived\\n"; }
};
Base* obj = new Derived();
obj->display(); // Resolves via Derived vptr`;

  const currentSnippet = activeLang === 'java' ? javaSnippet : cppSnippet;

  // Speech-to-text simulation
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isRecording) {
      timer = setInterval(() => {
        setResponse((prev) => {
          if (!prev.includes('Method overloading')) {
            return (
              prev +
              (prev ? ' ' : '') +
              'Method overloading is resolved at compile time, while method overriding is handled dynamically at runtime via vtables.'
            );
          }
          return prev;
        });
      }, 1500);
    }
    return () => clearInterval(timer);
  }, [isRecording]);

  const wordsCount = response.trim() ? response.trim().split(/\s+/).length : 0;
  const estimatedSeconds = Math.max(1, Math.round(wordsCount / 2.3));
  const estimatedWpm = wordsCount > 0 ? 134 : 0;

  const handleCopyCode = () => {
    navigator.clipboard?.writeText(currentSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleInsertSample = () => {
    setResponse(sampleAnswer);
  };

  const handleSubmit = () => {
    if (isSubmitting) return;
    setIsSubmitting(true);
    setSubmissionStep('Analyzing code rationale...');

    setTimeout(() => {
      setSubmissionStep('Synthesizing delivery cadence...');
      setTimeout(() => {
        const finalAnswer: SubmittedAnswer = {
          questionId: 'q-tcs-01',
          questionText:
            'In Java or C++, explain the difference between method overloading and method overriding. How does runtime polymorphism work under the hood using vtables or dynamic method dispatch?',
          mode: 'standard',
          studentAnswer:
            response.trim() ||
            'Method overloading is resolved at compile time, whereas method overriding resolves at runtime via vtable dynamic method dispatch.',
          feedback:
            'Exceptional depth on vtable function pointers and dynamic method dispatch resolution.',
          codeUnderstandingScore: 88,
          speakingDeliveryScore: 80,
          trapHandledCorrectly: true,
        };

        const newResult: InterviewResult = {
          id: `res-${Date.now()}`,
          studentId: 'std-104',
          projectId: selectedProject.id,
          projectTitle: selectedProject.title,
          date: 'Today',
          mode: 'standard',
          overallScore: 84,
          codeUnderstandingScore: 88,
          speakingDeliveryScore: 80,
          questionsAnswered: 1,
          totalQuestions: 1,
          strengths: [
            'Accurate explanation of database pushdown vs client heap memory limits',
            'Clear understanding of runtime polymorphism and virtual method tables',
          ],
          areasToImprove: [
            'Provide more concrete numbers when discussing Redis memory overhead',
          ],
          recommendedPracticeTopics: [
            'Virtual method table (vtable) memory footprint in C++ vs Java',
            'JVM inline caching optimizations',
          ],
          answers: [finalAnswer],
          deliveryMetrics: {
            structure: 'Structured (Context -> Technical Rationale -> Concrete Outcome)',
            pace: '138 words / minute (Optimal)',
            pauses: 'Natural pause cadence with confident technical synthesis',
            fillerWords: '0 detected (Clean Delivery)',
          },
        };

        onCompleteInterview(newResult);
        onNavigate('results');
      }, 250);
    }, 320);
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card with Question Progress */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-[#172033]">
              Question 1 of 1
            </span>
            <span className="text-xs text-[#64748B] font-medium">
              (100% complete)
            </span>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="px-2.5 py-0.5 rounded-md bg-[#EAF4FF] text-[#2563EB] font-bold border border-[#BFDBFE] transition-colors">
              TCS
            </span>
            <span className="px-2.5 py-0.5 rounded-md bg-[#F0FDFA] text-[#0D9488] font-bold border border-[#99F6E4] transition-colors">
              Technical Interview
            </span>
            <span className="px-2.5 py-0.5 rounded-md bg-[#F1F5F9] text-[#64748B] font-bold border border-[#E2E8F0] transition-colors">
              EASY
            </span>
          </div>
        </div>

        {/* Full-width Teal Progress Bar with animated entrance */}
        <div className="w-full bg-[#E2E8F0] h-1.5 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: '100%' }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="bg-[#14B8A6] h-full rounded-full"
          />
        </div>
      </div>

      {/* Main 2-Column Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Columns: Question, Snippet, Response */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white border border-[#E2E8F0] rounded-xl p-6 shadow-xs space-y-5">
            {/* Header: Topic & Track */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-[#E2E8F0]">
              <div className="flex items-center gap-2.5">
                <Code2 className="w-4 h-4 text-[#3B82F6]" />
                <span className="text-sm font-bold text-[#172033]">
                  OOPs &amp; Polymorphism
                </span>
                <span className="text-xs text-[#64748B]">
                  Track: TCS Ninja
                </span>
              </div>
              <span className="self-start sm:self-auto text-[11px] font-semibold text-[#D97706] bg-[#FFFBEB] px-2.5 py-0.5 rounded-md border border-[#FDE68A]">
                Curated Pattern Demonstration
              </span>
            </div>

            {/* Question Text Box */}
            <div className="p-4 bg-[#F8FAFC] rounded-xl border border-[#E2E8F0]">
              <p className="text-sm font-medium text-[#172033] leading-relaxed">
                In Java or C++, explain the difference between method overloading and method overriding. How does runtime polymorphism work under the hood using vtables or dynamic method dispatch?
              </p>
            </div>

            {/* Code Snippet Box with language toggle */}
            <div className="rounded-xl overflow-hidden border border-[#1E293B] bg-[#0F1E33] text-white">
              <div className="px-4 py-2 bg-[#182C48] flex items-center justify-between border-b border-[#243B5C] text-xs">
                <div className="flex items-center gap-2">
                  <div className="flex items-center bg-[#0F1E33] rounded-lg p-0.5 border border-[#243B5C]">
                    <button
                      onClick={() => setActiveLang('java')}
                      className={`relative px-2.5 py-1 text-xs font-mono rounded-md transition-colors cursor-pointer ${
                        activeLang === 'java' ? 'text-white font-bold' : 'text-[#94A3B8] hover:text-white'
                      }`}
                    >
                      {activeLang === 'java' && (
                        <motion.div
                          layoutId="active-code-lang"
                          className="absolute inset-0 bg-[#2563EB] rounded-md -z-10"
                          transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                        />
                      )}
                      Java
                    </button>
                    <button
                      onClick={() => setActiveLang('cpp')}
                      className={`relative px-2.5 py-1 text-xs font-mono rounded-md transition-colors cursor-pointer ${
                        activeLang === 'cpp' ? 'text-white font-bold' : 'text-[#94A3B8] hover:text-white'
                      }`}
                    >
                      {activeLang === 'cpp' && (
                        <motion.div
                          layoutId="active-code-lang"
                          className="absolute inset-0 bg-[#2563EB] rounded-md -z-10"
                          transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                        />
                      )}
                      C++
                    </button>
                  </div>
                  <span className="font-mono text-[#94A3B8] text-[11px] hidden sm:inline">
                    // Dynamic Dispatch Demonstration
                  </span>
                </div>

                <button
                  onClick={handleCopyCode}
                  className="inline-flex items-center gap-1.5 text-xs text-[#94A3B8] hover:text-white transition-colors cursor-pointer"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#14B8A6]" />
                      <span className="text-[#14B8A6]">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Snippet</span>
                    </>
                  )}
                </button>
              </div>
              <AnimatePresence mode="wait">
                <motion.pre
                  key={activeLang}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.15 }}
                  className="p-4 text-xs font-mono leading-relaxed text-[#E2E8F0] overflow-x-auto whitespace-pre"
                >
                  {currentSnippet}
                </motion.pre>
              </AnimatePresence>
            </div>

            {/* Response Area */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label
                  htmlFor="response-input"
                  className="text-xs font-bold text-[#172033]"
                >
                  Your Spoken or Written Response:
                </label>
                <button
                  type="button"
                  onClick={handleInsertSample}
                  className="text-xs text-[#3B82F6] hover:underline font-semibold cursor-pointer inline-flex items-center gap-1 transition-colors"
                >
                  <Terminal className="w-3.5 h-3.5" />
                  <span>&gt;_ Insert Sample Answer</span>
                </button>
              </div>

              <textarea
                id="response-input"
                rows={6}
                value={response}
                onChange={(e) => setResponse(e.target.value)}
                placeholder="Explain your technical reasoning: state architecture tradeoffs, concurrency safety, and why your approach satisfies TCS's standards..."
                className="w-full p-4 text-xs text-[#172033] bg-white rounded-xl border border-[#CBD5E1] focus:border-[#3B82F6] focus:ring-2 focus:ring-[#3B82F6]/15 outline-none leading-relaxed transition-all placeholder:text-[#94A3B8]"
              />

              <div className="flex items-center justify-between text-[11px] text-[#64748B] mt-1.5">
                <span className="transition-all">{wordsCount} words drafted</span>
                <span className="transition-all">~ {estimatedSeconds}s speaking duration</span>
              </div>
            </div>

            {/* Action Row */}
            <div className="pt-4 border-t border-[#E2E8F0] flex items-center justify-between gap-3 flex-wrap">
              <button
                type="button"
                disabled
                className="px-4 py-2.5 rounded-lg border border-[#E2E8F0] text-xs font-medium text-[#94A3B8] bg-[#F8FAFC] cursor-not-allowed"
              >
                &lt; Previous
              </button>

              <div className="flex items-center gap-3">
                <motion.button
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.98 }}
                  type="button"
                  onClick={() => setIsRecording(!isRecording)}
                  className={`relative inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                    isRecording
                      ? 'bg-[#FEF2F2] border-[#EF4444] text-[#DC2626]'
                      : 'bg-white border-[#CBD5E1] text-[#172033] hover:bg-[#F8FAFC]'
                  }`}
                >
                  {isRecording ? (
                    <>
                      <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#EF4444] opacity-75" />
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-[#EF4444]" />
                      </span>
                      <MicOff className="w-4 h-4 text-[#DC2626]" />
                      <span>Stop Recording</span>
                    </>
                  ) : (
                    <>
                      <Mic className="w-4 h-4 text-[#3B82F6]" />
                      <span>Record Mic (Speech)</span>
                    </>
                  )}
                </motion.button>

                <motion.button
                  whileHover={{ scale: isSubmitting ? 1 : 1.01 }}
                  whileTap={{ scale: isSubmitting ? 1 : 0.98 }}
                  type="button"
                  disabled={isSubmitting}
                  onClick={handleSubmit}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-xs font-semibold bg-[#183653] hover:bg-[#254B70] text-white transition-all cursor-pointer shadow-xs disabled:opacity-85"
                >
                  {isSubmitting ? (
                    <>
                      <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>{submissionStep}</span>
                    </>
                  ) : (
                    <>
                      <span>Submit &amp; Complete Session</span>
                      <Send className="w-3.5 h-3.5" />
                    </>
                  )}
                </motion.button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Sidebar: Camera, Live Speaking Heuristics, Round Questions */}
        <div className="space-y-6">
          {/* Candidate Camera Card */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 shadow-xs card-hover">
            <div className="flex items-center justify-between mb-3 text-xs">
              <div className="flex items-center gap-2 font-bold text-[#172033]">
                <VideoOff className="w-4 h-4 text-[#3B82F6]" />
                <span>Candidate Camera</span>
              </div>
              <button
                type="button"
                onClick={() => setCameraActive(!cameraActive)}
                className="text-[#3B82F6] hover:underline font-semibold cursor-pointer transition-colors"
              >
                {cameraActive ? 'Disable Camera' : 'Enable Camera'}
              </button>
            </div>

            {/* Video Viewport */}
            <div className="w-full h-44 rounded-xl bg-[#0F1E33] border border-[#1E293B] flex flex-col items-center justify-center p-4 text-center transition-all duration-300">
              {cameraActive ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="space-y-2"
                >
                  <div className="w-10 h-10 rounded-full bg-[#14B8A6]/20 border border-[#14B8A6] flex items-center justify-center mx-auto text-[#14B8A6]">
                    <CheckCircle className="w-5 h-5" />
                  </div>
                  <p className="text-xs font-semibold text-white">Live Camera Active</p>
                  <p className="text-[10px] text-[#94A3B8]">Candidate feed streamed locally</p>
                </motion.div>
              ) : (
                <div className="space-y-2">
                  <div className="w-8 h-8 rounded-full bg-[#182C48] flex items-center justify-center mx-auto text-[#94A3B8]">
                    <VideoOff className="w-4 h-4" />
                  </div>
                  <p className="text-xs font-bold text-white">
                    Simulated Camera Placeholder
                  </p>
                  <p className="text-[10px] text-[#94A3B8] max-w-[200px] leading-tight mx-auto">
                    Hardware webcam is offline. Click &quot;Enable Camera&quot; above to activate live feed.
                  </p>
                  <span className="inline-block mt-1 text-[9px] font-mono uppercase tracking-wider px-2 py-0.5 rounded bg-[#182C48] text-[#94A3B8] border border-[#243B5C]">
                    DEMONSTRATION SIMULATION
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Live Speaking Heuristics Card */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 shadow-xs space-y-4 card-hover">
            <div className="flex items-center justify-between pb-3 border-b border-[#E2E8F0]">
              <div>
                <h3 className="text-xs font-bold text-[#172033]">
                  Live Speaking Heuristics
                </h3>
                <p className="text-[11px] text-[#64748B]">
                  Real time client speech cadence
                </p>
              </div>
              <span className="text-[10px] font-bold text-[#0D9488] bg-[#F0FDFA] px-2 py-0.5 rounded border border-[#99F6E4]">
                Live Metrics
              </span>
            </div>

            {/* Speech Cadence with smooth animated bar */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-[#64748B] font-medium">Speech Cadence</span>
                <span className="text-[#0D9488] font-bold font-mono">
                  ~{estimatedWpm} WPM (Optimal)
                </span>
              </div>
              <div className="w-full bg-[#E2E8F0] h-1.5 rounded-full overflow-hidden">
                <motion.div
                  className="bg-[#14B8A6] h-full rounded-full"
                  animate={{ width: wordsCount > 0 ? '75%' : '15%' }}
                  transition={{ duration: 0.35, ease: 'easeOut' }}
                />
              </div>
            </div>

            {/* Answer Structure Analysis */}
            <div className="space-y-1">
              <span className="text-xs text-[#64748B] font-medium">
                Answer Structure Analysis
              </span>
              <div className="p-2.5 rounded-lg bg-[#F8FAFC] border border-[#E2E8F0] text-xs text-[#172033] transition-all">
                {wordsCount > 30 ? (
                  <motion.span
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-[#16A34A] font-medium"
                  >
                    Strong Technical Synthesis (Context -&gt; Dynamic Vtable -&gt; Resolution)
                  </motion.span>
                ) : (
                  <span className="text-[#64748B]">Drafting response...</span>
                )}
              </div>
            </div>

            {/* Filler Word Rate */}
            <div className="flex items-center justify-between text-xs pt-1">
              <span className="text-[#64748B] font-medium">Filler Word Rate</span>
              <span className="text-[#16A34A] font-semibold text-[11px]">
                0 detected (Clean Delivery)
              </span>
            </div>
          </div>

          {/* Round Questions Selector */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 shadow-xs card-hover">
            <h3 className="text-xs font-bold text-[#172033] mb-3">
              Round Questions (1)
            </h3>
            <div className="p-3 rounded-xl bg-[#EAF4FF] border border-[#3B82F6] flex items-center justify-between transition-all">
              <span className="text-xs font-bold text-[#1D4ED8]">
                Q1: OOPs &amp; Polymorphism
              </span>
              <span className="w-2 h-2 rounded-full bg-[#3B82F6] animate-pulse" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
